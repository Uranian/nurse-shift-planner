// 📄 src/pages/admin-users.jsx

import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { supabase } from "../lib/supabaseClient";

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [hospitals, setHospitals] = useState([]);
  const [wards, setWards] = useState([]);
  const [search, setSearch] = useState("");
  const [newUser, setNewUser] = useState({
    username: "",
    email: "",
    password: "",
    phone: "",
    hospital_id: "",
    ward_id: "",
    role: "staff",
  });

  const [editUser, setEditUser] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const { data: usersData } = await supabase
      .from("profiles")
      .select("*, hospitals(name), wards(name)")
      .order("email", { ascending: true });
    setUsers(usersData || []);

    const { data: hospitalsData } = await supabase.from("hospitals").select();
    setHospitals(hospitalsData || []);

    const { data: wardsData } = await supabase.from("wards").select();
    setWards(wardsData || []);
  };

  const handleChange = (field, value) => {
    setNewUser((prev) => ({ ...prev, [field]: value }));
  };

  const handleAdd = async () => {
    if (
      !newUser.email ||
      !newUser.password ||
      !/^[0-9]{8}$/.test(newUser.password) ||
      !newUser.hospital_id ||
      !newUser.ward_id
    ) {
      toast.error("กรุณากรอกข้อมูลให้ครบถ้วน และรหัสผ่านต้องเป็นตัวเลข 8 หลัก");
      return;
    }
    await supabase.from("profiles").insert([newUser]);
    setNewUser({
      username: "",
      email: "",
      password: "",
      phone: "",
      hospital_id: "",
      ward_id: "",
      role: "staff",
    });
    fetchData();
  };

  const handleUpdate = async () => {
    if (!editUser.email || !editUser.hospital_id || !editUser.ward_id) return;

    const updatedFields = {
      email: editUser.email,
      username: editUser.username,
      phone: editUser.phone,
      hospital_id: editUser.hospital_id,
      ward_id: editUser.ward_id,
      role: editUser.role,
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabase
      .from("profiles")
      .update(updatedFields)
      .eq("id", editUser.id);

    if (error) {
      console.error("Update failed:", error);
    }

    setEditUser(null);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (!confirm("ยืนยันลบผู้ใช้นี้?")) return;
    await supabase.from("profiles").delete().eq("id", id);
    fetchData();
  };

  const filtered = users.filter((u) =>
    [u.email, u.username, u.phone].some((field) =>
      field?.toLowerCase().includes(search.toLowerCase())
    )
  );

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">👥 จัดการผู้ใช้</h1>

      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="ค้นหา email, username, เบอร์โทร"
        className="border px-2 py-1 mb-2 w-full"
      />

      <div className="mb-4 flex gap-2 flex-wrap items-center bg-white text-black p-4 rounded">
        <input
          value={newUser.username}
          onChange={(e) => handleChange("username", e.target.value)}
          placeholder="username"
          className="border px-2 py-1"
        />
        <input
          value={newUser.email}
          onChange={(e) => handleChange("email", e.target.value)}
          placeholder="email"
          className="border px-2 py-1"
        />
        <input
          value={newUser.password}
          onChange={(e) => handleChange("password", e.target.value)}
          placeholder="รหัสผ่าน 8 หลัก"
          className="border px-2 py-1"
          type="password"
        />
        <input
          value={newUser.phone}
          onChange={(e) => handleChange("phone", e.target.value)}
          placeholder="เบอร์โทร"
          className="border px-2 py-1"
        />
        <select
          value={newUser.hospital_id}
          onChange={(e) => handleChange("hospital_id", e.target.value)}
          className="border px-2 py-1"
        >
          <option value="">เลือกโรงพยาบาล</option>
          {hospitals.map((h) => (
            <option key={h.id} value={h.id}>
              {h.name}
            </option>
          ))}
        </select>
        <select
          value={newUser.ward_id}
          onChange={(e) => handleChange("ward_id", e.target.value)}
          className="border px-2 py-1"
        >
          <option value="">เลือกวอร์ด</option>
          {wards.map((w) => (
            <option key={w.id} value={w.id}>
              {w.name}
            </option>
          ))}
        </select>
        <select
          value={newUser.role}
          onChange={(e) => handleChange("role", e.target.value)}
          className="border px-2 py-1"
        >
          <option value="staff">staff</option>
          <option value="admin">admin</option>
        </select>
        <button
          onClick={handleAdd}
          className="bg-green-600 text-white px-3 py-1 rounded"
        >
          ➕ เพิ่มผู้ใช้
        </button>
      </div>

      {editUser && (
        <div className="mb-4 border p-4 bg-gray-200 rounded text-black">
          <h2 className="text-lg font-semibold mb-2 text-black">
            ✏️ แก้ไขผู้ใช้
          </h2>
          <input
            value={editUser.username || ""}
            onChange={(e) =>
              setEditUser({ ...editUser, username: e.target.value })
            }
            placeholder="username"
            className="border px-2 py-1 mr-2"
          />
          <input
            value={editUser.email || ""}
            onChange={(e) =>
              setEditUser({ ...editUser, email: e.target.value })
            }
            placeholder="email"
            className="border px-2 py-1 mr-2"
          />
          <input
            value={editUser.phone || ""}
            onChange={(e) =>
              setEditUser({ ...editUser, phone: e.target.value })
            }
            placeholder="เบอร์โทร"
            className="border px-2 py-1 mr-2"
          />
          <select
            value={editUser.hospital_id}
            onChange={(e) =>
              setEditUser({ ...editUser, hospital_id: e.target.value })
            }
            className="border px-2 py-1 mr-2"
          >
            <option value="">เลือกโรงพยาบาล</option>
            {hospitals.map((h) => (
              <option key={h.id} value={h.id}>
                {h.name}
              </option>
            ))}
          </select>
          <select
            value={editUser.ward_id}
            onChange={(e) =>
              setEditUser({ ...editUser, ward_id: e.target.value })
            }
            className="border px-2 py-1 mr-2"
          >
            <option value="">เลือกวอร์ด</option>
            {wards.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
          <select
            value={editUser.role}
            onChange={(e) => setEditUser({ ...editUser, role: e.target.value })}
            className="border px-2 py-1 mr-2"
          >
            <option value="staff">staff</option>
            <option value="admin">admin</option>
          </select>
          <button
            onClick={handleUpdate}
            className="bg-blue-600 text-white px-3 py-1 rounded mr-2"
          >
            💾 บันทึก
          </button>
          <button
            onClick={() => setEditUser(null)}
            className="text-gray-600 underline"
          >
            ยกเลิก
          </button>
        </div>
      )}

      <table className="table-auto w-full border-collapse">
        <thead>
          <tr>
            <th className="border px-2 py-1">Username</th>
            <th className="border px-2 py-1">Email</th>
            <th className="border px-2 py-1">เบอร์โทร</th>
            <th className="border px-2 py-1">โรงพยาบาล</th>
            <th className="border px-2 py-1">วอร์ด</th>
            <th className="border px-2 py-1">Role</th>
            <th className="border px-2 py-1">จัดการ</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((user) => (
            <tr key={user.id}>
              <td className="border px-2 py-1">{user.username || "-"}</td>
              <td className="border px-2 py-1">{user.email}</td>
              <td className="border px-2 py-1">{user.phone || "-"}</td>
              <td className="border px-2 py-1">
                {user.hospitals?.name || "-"}
              </td>
              <td className="border px-2 py-1">{user.wards?.name || "-"}</td>
              <td className="border px-2 py-1">{user.role}</td>
              <td className="border px-2 py-1">
                <button
                  onClick={() => setEditUser(user)}
                  className="text-blue-600 hover:underline mr-2"
                >
                  แก้ไข
                </button>
                <button
                  onClick={() => handleDelete(user.id)}
                  className="text-red-500 hover:underline"
                >
                  ลบ
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
