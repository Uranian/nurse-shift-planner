// config.js
export const DEFAULT_HOSPITAL_ID = "9316323d-4555-408b-bc80-e96e9e87079f";
export const DEFAULT_WARD_ID = "68424e71-3a30-4e7c-9176-103d5f93f214";
export const DEFAULT_HOSPITAL_NAME = "โรงพยาบาลสมมติ (สาธิต)";
export const DEFAULT_WARD_NAME = "วอร์ดสูติ-นรีเวช (ตัวอย่าง)";
