// 🔽 pages/consultant-booking-table.jsx

import React, { useState } from "react";
import Modal from "react-modal";

Modal.setAppElement("#__next"); // สำหรับ accessibility

export default function BookingModal({ isOpen, onClose, slot, onConfirm }) {
  if (!slot) return null;

  const { consultant, date, start_time, end_time, price } = slot;

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onClose}
      contentLabel="ยืนยันการจอง"
      className="bg-white max-w-md mx-auto mt-20 p-6 rounded shadow-lg"
      overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center"
    >
      <h2 className="text-xl font-semibold mb-4">📌 ยืนยันการจอง</h2>

      <div className="mb-4 space-y-2">
        <p>👤 ที่ปรึกษา: <strong>{consultant.nickname || consultant.username}</strong></p>
        <p>📅 วันที่: <strong>{date}</strong></p>
        <p>⏰ เวลา: <strong>{start_time} - {end_time}</strong></p>
        <p>💰 ราคา: <strong>{price.toLocaleString()} บาท</strong></p>
      </div>

      <div className="flex justify-end space-x-2">
        <button
          onClick={onClose}
          className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
        >
          ❌ ยกเลิก
        </button>
        <button
          onClick={() => {
            onConfirm(slot);
            onClose();
          }}
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          ✅ ยืนยันการจอง
        </button>
      </div>
    </Modal>
  );
}
